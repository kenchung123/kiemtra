package bean;
//lay va gan cac gia tri
public class canbobean {
	private String macb;
	private String ht;
	private double hsl;
	private String ngaysinh;
	private String email;
	public String getMacb() {
		return macb;
	}
	public void setMacb(String macb) {
		this.macb = macb;
	}
	public String getht() {
		return ht;
	}
	public void setht(String ht) {
		this.ht = ht;
	}
	public Double getHsl() {
		return hsl;
	}
	public void setHsl(double d) {
		this.hsl = d;
	}
	public String getNgaysinh() {
		return ngaysinh;
	}
	public void setNgaysinh(String ngaysinh) {
		this.ngaysinh = ngaysinh;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
}
