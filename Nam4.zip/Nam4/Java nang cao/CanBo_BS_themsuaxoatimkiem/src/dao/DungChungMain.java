package dao;

public class DungChungMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			DungChung dc=new DungChung();
			dc.KetNoi();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

}
